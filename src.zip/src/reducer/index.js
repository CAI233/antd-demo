import { combineReducers } from 'redux'
import puplic from './puplic'
import home from './home'

export default combineReducers({
    puplic,
    home
})