import React, { Component } from 'react';
 
class tab5 extends Component {
    constructor (props) {
        super(props)
        // console.log(props)
    }
 
   render() {
       return (
            <p>Message5</p>
       );
   }
}
 
export default tab5