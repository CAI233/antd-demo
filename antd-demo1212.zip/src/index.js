import React from 'react';
import ReactDOM from 'react-dom';
import Router from './Router';
import './index.css';
import * as serviceWorker from './serviceWorker';
// https://blog.csdn.net/awaw00/article/category/6642917 
//原文链接  react学习 http://huziketang.mangojuice.top/books/react/lesson14
//react学习  https://github.com/minooo/React-Study
ReactDOM.render(<Router/>, document.getElementById('root'));
console.log(123);
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
