import React, { Component } from 'react';
 
class tab4 extends Component {
    constructor (props) {
        super(props)
        // console.log(props)
    }
 
   render() {
       return (
            <p>Message4</p>
       );
   }
}
 
export default tab4