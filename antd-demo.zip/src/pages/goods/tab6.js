import React, { Component } from 'react';
 
class tab6 extends Component {
    constructor (props) {
        super(props)
        // console.log(props)
    }
 
   render() {
       return (
            <p>Message6</p>
       );
   }
}
 
export default tab6