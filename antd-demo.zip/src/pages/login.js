import React from 'react';

import { WhiteSpace } from 'antd-mobile';


const PlaceHolder = ({ className = '', ...restProps }) => (
    
  <div className={`${className} placeholder`} {...restProps}>Block</div>
);

// .placeholder {
//   background-color: #ebebef;
//   color: #bbb;
//   text-align: center;
//   height: 30px;
//   line-height: 30px;
//   width: 100%;
// }

export default class Login extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            id:3
          };
    }
    render() {
        // var placeholder = {
        //     backgroundColor: '#ebebef',
        //     color: '#bbb',
        //     textAlign: 'center',
        //     height: '30px',
        //     lineHeight: '30px',
        //     width: '100%'
        // }
        return (
            <div className="container">
                <a >Login页面</a>   
                <p onClick={() => this.props.history.push('/home')}>去首页</p>
                <div>
                    <WhiteSpace size="xs" />
                    <PlaceHolder />
                
                    <WhiteSpace size="sm" />
                    <PlaceHolder />
                
                    <WhiteSpace />
                    <PlaceHolder />
                
                    <WhiteSpace size="lg" />
                    <PlaceHolder />
                
                    <WhiteSpace size="xl" />
                    <PlaceHolder />
                </div>
            </div>
        )
    }
}